# פרויקט גמר — זיהוי דפוסי EEG בזמן אמת
**נועה כהן | מנחה: פרופ׳ דוד לוי | הנדסת חשמל, טכניון**

---

## תיאור הפרויקט

פיתוח מערכת לזיהוי אוטומטי של אירועי פרכוסת (seizures) בקריאות EEG בזמן אמת.
המערכת צריכה לזהות דפוסים חריגים תוך פחות מ-500ms מרגע הופעתם.

## מצב נוכחי

### מה עובד ✅
- קריאת קבצי EDF עם MNE
- פילטרציה בסיסית (bandpass 0.5-40 Hz)
- חלון הזזה (sliding window) על הנתונים
- ויזואליזציה של ערוצים

### מה לא עובד ❌
- detection rate נמוך מדי (70% — צריך 90%+)
- False positive rate גבוה בשעות הלילה
- latency של ~800ms — מעל היעד של 500ms

### הקוד הנוכחי (עם הבאג)
```python
import mne
import numpy as np
from scipy import signal

def detect_seizure(raw_data, sfreq=256):
    """
    זיהוי seizure בחלון של 2 שניות
    raw_data: numpy array (channels x samples)
    """
    # פילטר bandpass
    b, a = signal.butter(4, [0.5, 40], btype='bandpass', fs=sfreq)
    filtered = signal.filtfilt(b, a, raw_data, axis=1)
    
    # Feature extraction
    power = np.mean(filtered**2, axis=1)  # RMS power per channel
    
    # זיהוי — threshold פשוט
    threshold = np.mean(power) + 2 * np.std(power)
    
    # ??? כאן משהו לא עובד
    # כשיש seizure האות מתנדנד בתדר 3-5 Hz
    # הפילטר הרחב מדי לוכד גם תנועות שרירים (>20 Hz)
    
    return np.any(power > threshold)
```

## שאלות לפרופ׳ לוי — פגישה 12.10.2026
1. האם כדאי לעבור ל-wavelet transform במקום FFT?
2. איך מטפלים ב-artifact removal (עיני, שרירים) בזמן אמת?
3. ML approach — האם SVM על features עדיף על threshold?

## ציר זמן
| תאריך | משימה |
|--------|--------|
| 15.10.2026 | סיום artifact removal |
| 01.11.2026 | שיפור detection algorithm |
| 15.11.2026 | בדיקה על dataset מלא |
| 01.12.2026 | טיוטת דוח גמר |
| 15.01.2027 | הגשת דוח סופי |
| 01.02.2027 | הצגת פרויקט |

## קבצים רלוונטיים
- `data/eeg_sample_01.edf` — מדגם לבדיקה (40 שניות)
- `src/detector.py` — הקוד הראשי
- `src/visualizer.py` — ויזואליזציה
- `notebooks/exploration.ipynb` — ניסויים ראשוניים
- `results/detection_report_v2.pdf` — דוח ביצועים אחרון
