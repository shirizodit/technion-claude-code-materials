# סיכום שיעורים — DSP | נועה כהן

---

## שיעור 3 — תמרת DFT

### מה זה DFT?
DFT = Discrete Fourier Transform. ממירה רצף דיסקרטי בזמן לרצף דיסקרטי בתדר.

**הגדרה:**
$$X[k] = \sum_{n=0}^{N-1} x[n] \cdot e^{-j2\pi kn/N}, \quad k = 0, 1, ..., N-1$$

### תכונות חשובות שלוי שם עליהן דגש:
1. **Linearity** — DFT{ax+by} = aDFT{x} + bDFT{y}
2. **Circular shift** — הזזה בזמן = כפל בפאזה בתדר
3. **Parseval's theorem** — אנרגיה נשמרת בין תחומים
4. **Symmetry** — לאות ממשי: X[N-k] = X*[k]

### קוד Python — DFT ידנית vs NumPy:
```python
import numpy as np
import matplotlib.pyplot as plt

# אות לדוגמה
N = 64
n = np.arange(N)
x = np.sin(2 * np.pi * 5 * n / N) + 0.5 * np.sin(2 * np.pi * 12 * n / N)

# DFT עם NumPy
X = np.fft.fft(x)
freqs = np.fft.fftfreq(N)

# ויזואליזציה
plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(n, x)
plt.title('אות בתחום הזמן')
plt.xlabel('n')

plt.subplot(1, 2, 2)
plt.plot(freqs[:N//2], np.abs(X[:N//2]))
plt.title('ספקטרום תדר (DFT)')
plt.xlabel('תדר מנורמל')
plt.tight_layout()
plt.show()
```

### שאלה מהתרגול שלא הבנתי:
> "נתון אות x[n] = cos(0.2πn). חשבו את DFT עבור N=10. האם התוצאה הגיונית?"

**תשובה (מד״ר ברק):** cos(0.2πn) = (e^{j0.2πn} + e^{-j0.2πn})/2. בDFT עם N=10: תדר 0.2π מתאים ל-k=1 ו-k=9. כן, הגיוני.

---

## שיעור 4 — FFT

### למה FFT ולא DFT ישיר?
- DFT ישיר: O(N²) פעולות
- FFT: O(N log N) פעולות
- עבור N=1024: DFT = 1,048,576 | FFT = 10,240 — **פי 100 יותר מהיר!**

### Butterfly Diagram (חשוב לבחינה!):
FFT מפצלת את החישוב ל-log₂(N) שלבים. בכל שלב: butterflies.

```
x[0] ──┬──── W⁰ ──→ X[0]
       ×
x[4] ──┴──── W¹ ──→ X[1]
```

### יישום — ניתוח רעש בקול:
```python
import scipy.io.wavfile as wav
import numpy as np

# קריאת קובץ שמע
rate, data = wav.read('speech.wav')
data = data / np.max(np.abs(data))  # normalization

# FFT
N = len(data)
X = np.fft.fft(data)
freqs = np.fft.fftfreq(N, 1/rate)

# הצגת ספקטרום
# תדרי קול אנושי: 85-3400 Hz
mask = (freqs > 0) & (freqs < 4000)
```

### שאלה לפרופ׳:
מה קורה אם N לא חזקה של 2? → zero-padding! נוסיף אפסים עד הגודל הבא.

---

## שיעור 7 — תמרת Z

### הגדרה:
$$X(z) = \sum_{n=-\infty}^{\infty} x[n] z^{-n}$$

### Region of Convergence (ROC) — חשוב לבחינה:
- Causal signal: ROC הוא חוץ למעגל
- Anti-causal: ROC הוא פנים למעגל  
- Two-sided: ROC הוא טבעת

### קשר בין Z לDTFT:
DTFT = Z על המעגל היחידה: z = e^{jω}

### Poles & Zeros — ויזואליזציה:
```python
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle

def plot_pole_zero(zeros, poles):
    fig, ax = plt.subplots(1, 1, figsize=(6, 6))
    
    # מעגל יחידה
    theta = np.linspace(0, 2*np.pi, 100)
    ax.plot(np.cos(theta), np.sin(theta), 'b--', alpha=0.3)
    
    # zeros (עיגולים)
    for z in zeros:
        ax.plot(z.real, z.imag, 'bo', markersize=12, fillstyle='none')
    
    # poles (איקסים)
    for p in poles:
        ax.plot(p.real, p.imag, 'rx', markersize=12, markeredgewidth=2)
    
    ax.axhline(0, color='k', linewidth=0.5)
    ax.axvline(0, color='k', linewidth=0.5)
    ax.set_xlabel('Re(z)')
    ax.set_ylabel('Im(z)')
    ax.set_title('Pole-Zero Plot')
    ax.grid(True, alpha=0.3)
    ax.set_aspect('equal')
    plt.show()

# דוגמה: פילטר FIR פשוט
zeros = [1, -1]
poles = [0]
plot_pole_zero(zeros, poles)
```

---

## דברים שלא מבינה — לשאול בתרגול

1. למה ROC לא כולל poles? (אינטואיציה)
2. קשר בין יציבות BIBO לROC — האם תמיד זה אותו דבר?
3. תמרת Z הפוכה עם partial fractions — כשיש poles מרוכבים

---

## נוסחאות שחשוב לזכור לבחינה

| נוסחה | הערה |
|-------|------|
| DFT: X[k] = Σ x[n]·W^{nk}, W=e^{-j2π/N} | לדעת בעל פה |
| Z: X(z) = Σ x[n]·z^{-n} | הגדרה |
| DTFT: X(e^{jω}) = Σ x[n]·e^{-jωn} | |
| פארסבל: Σ\|x[n]\|² = (1/N)·Σ\|X[k]\|² | שמירת אנרגיה |
| Convolution ↔ Multiplication | בתחום התדר! |
