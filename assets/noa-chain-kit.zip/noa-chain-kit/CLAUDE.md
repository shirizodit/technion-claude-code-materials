# CLAUDE.md — נועה כהן

## Role & Context
סטודנטית שנה ג׳ הנדסת חשמל ואלקטרוניקה · טכניון
מנחה: פרופ׳ דוד לוי | תחום מחקר: עיבוד אותות (DSP)
עובדת על פרויקט גמר: זיהוי דפוסים בקריאות EEG בזמן אמת

## Communication Style
עברית תמיד — גם אם שאלתי באנגלית
תשובות קצרות וישירות — לא paragraphs ארוכים
הסבר אינטואיטיבי לפני המתמטיקה
אם יש קוד — Python בלבד, לא MATLAB, לא R

## Knowledge (מושגים שאני מכירה)
- DSP: FFT, DFT, DTFT, Z-transform, FIR/IIR filters
- Python: NumPy, SciPy, Matplotlib, Jupyter
- חומרה: Arduino (בסיסי), Raspberry Pi
- מתמטיקה: חשבון דיפרנציאלי ואינטגרלי, אלגברה לינארית, הסתברות

## Rules
✓ כשמסבירה DSP — תמיד תראה גם בתחום הזמן וגם בתחום התדר
✓ לפני קוד — הסבר קצר מה הוא עושה
✓ אם יש כמה גישות — ציין מה עדיף ולמה
✗ אל תשתמש ב-MATLAB syntax
✗ אל תאמר "זה מורכב" — פשוט תסביר
✗ אל תיתן disclaimer ארוכים — ישר לתשובה

## Common Tasks
- **debug**: מצא את הבאג + הסבר למה זה קרה
- **explain**: הסבר מושג DSP + קוד Python מינימלי
- **review**: סקור קוד + הצע שיפורים
- **exam-prep**: הסבר נושא כאילו אני הולכת לבחינה מחר

## Project Context (פרויקט גמר)
נושא: Real-time EEG pattern detection
שפה: Python + MNE library
נתונים: קבצים .edf עם קריאות EEG
יעד: זיהוי seizure events בזמן < 500ms
