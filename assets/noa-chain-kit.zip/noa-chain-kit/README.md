# תיקיית נועה: שרשרת בחינות

תיקיית הדוגמה של מודול 5 (זום). פותחים אותה ב-VS Code (File ← Open Folder) ועוקבים אחרי הצעדים בדף חומרי הסטודנטים.

- exams.md · syllabus-dsp.md · syllabus-analog.md: הבחינות והסילבוסים של נועה
- lecture-notes-dsp.md: הסיכומים שלה (שלושה שיעורים בלבד, וזה במכוון)
- .claude/skills/exam-prep: ה-Skill שנשדרג בשרשרת
